i_h = 1.5;
gacc = 9.8;
velocity = 4;
angle = 45;

y1 = linspace(0,1,1000);

x(t) = velocity*cos(angle*(pi/180));
y(t) = i_h + ((vvelocity*sin(angle*(pi/180)))*t) - ((1/2)*(g*(t^2)));

x1   = 1:0.1:5;

ind = find(x==min(x(i_h<0)));

plot3(t,x,y)
