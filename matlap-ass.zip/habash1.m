
a =10
b = 2.5*(10^23)
i = sqrt(-1)
c = 2 + (3*i)
d = exp(i*((2*pi)/3))

aVec = [3.14,15,9,26]
bVec = [2.71;8;28;182]
cVec = 5;-0.2;-5
dVec = logspace(0, 0.99);

aMat = ones(9) + zeros(9) + 1;
vector = [1, 2, 3, 4, 5, 4, 3, 2, 1];
bMat = zeros(9) + diag(vector, 0);
vecto = 1:100;
cMat = reshape(vecto, [10, 10]);
dMat = NaN(3, 4);
fMat = randi([-3, 3], 5, 3);
x = 1 / (1 + exp(-(a - 15) / 6));
y = (sqrt(a) + nthroot(b, 21))^pi;
z = log(real((c + d) * (c - d)) * sin(a * pi / 3)) / c * conj(c);



temp = dotprod(aVec, bVec);
xMat = dotprod(temp, aMat^2);
yMat = dotprod(bVec, aVec);
temp1 = dotprod(aMat, bMat);
tempo = transpose(temp1);
zMat = det(cMat) * tempo;


cSum = sum(cMat);
eMean = mean(eMat, 2)
tmp = [1 1 1];
eMat_replace = eMat;
eMat_replace(1, :) = tmp;
cSub = cMat(2:9, 2:9);