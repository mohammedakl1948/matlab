
function ind=findNearest(x, desiredVal)

x=abs(x(:)-desiredVal);

 m=min(x);

ind=find(x==m)';
end






function loopTest(N)

clc;
sigma=5;
mu=2;
v=randn(500,1).*sigma+mu;
for i=1:100000
avg=mean(v);
if abs(avg-mu)>abs(avgD-mu)
avgD=avg
end
sd=std(v);
if abs(sd-sigma)>abs(sdD-sigma)
sdD=sd
end
end


clc;
sigma=5;
mu=2;
v=randn(500,1).*sigma+mu;
for i=1:100000
    avg=mean(v);
    if abs(avg-mu)>abs(avgD-mu)
        avgD=avg
    end
    sd=std(v);
    if abs(sd-sigma)>abs(sdD-sigma)
        sdD=sd
    end
end



close all;
rep=10000;
flips=round(rand(1,rep));
 with this coin.
headEvent=cumsum(flips);
totalEvent=1:rep;
headProbability=headEvent./totalEvent;
plot(totalEvent,headProbability,totalEvent,0.5*ones(1,rep));

for i=1:N
  if mod(i,2)==0 && mod(i,3)==0
    disp([num2str(i), ' is divisible by 2 and 3 ']);
  endif
